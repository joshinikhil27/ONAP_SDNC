app.controller('dashboardCtrl',function($scope,$http,$filter,$rootScope,$state){
	function getJson(){
		$http.put('http://localhost:8087/demo/onap/ListDataSet')
	       .then(function(res){
	    	   $scope.tabledata = res.data;
	    });
	};
	getJson();
})
.directive('gridTable',function(){
    return {
        restrict : 'AE',
        scope : {
            griddata : '=',
            callfun : '&',
        },
        templateUrl : 'resources/directives/editable-grid.html',
        controller : function($scope,$http){
        	$scope.getTemplate = function (contact) {
    			$scope.counterid = [];
    			$scope.counterid.push($scope.model.selected.id);
        		if($scope.counterid[0] != undefined){	 
                    if (contact.id.counter === $scope.counterid[0].counter) return 'edit';
                        else return 'display';
        		}else{
        			return 'display';
        		}
            };
            $scope.model = {selected : {}};
            $scope.editContact = function (contact) {
                $scope.model.selected = angular.copy(contact);
            };
            
            $scope.saveContact = function (idx) {
            	$scope.editableRow;
                $scope.editableRow= angular.copy($scope.model.selected);
                console.log('editableRow '+ JSON.stringify($scope.editableRow));
                $scope.griddata[idx] = angular.copy($scope.model.selected);
                $http({
					url : 'http://localhost:8087/demo/onap/updateDataSet',
					contentType : "application/json",
					method : 'POST',
					 data: $scope.editableRow 
					//data : angular.toJson(objTemp)
				}).then(function(success) {
					console.log(success)
				}, function(err) {
					console.log(err)
				});
                
                $scope.reset();
            };

            $scope.reset = function () {
                $scope.model.selected = {};
            };
        }
    };
})
.directive('graphTable',function(){
	    return {
	        restrict : 'AE',
	        scope : {
	            tabledata : '=',
	            header : '=',
	            callfun : '&',
	            styleclass : '=',
	        },
	        templateUrl : 'resources/directives/graph-data.html',
	        link: function($scope, element, attrs) {
	           
	        }
	    };
});