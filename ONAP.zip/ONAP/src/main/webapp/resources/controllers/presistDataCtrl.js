app.controller('presistDataCtrl',function($scope,$http,$filter,$rootScope,$state,$window){
/*
	$scope.currentTask=false;
	$scope.nextTask=false;
	$scope.finalTask=false;
	$scope.closeButton=false;
	$scope.nextTaskFail=false;
	$scope.finalTaskFail=false;*/
	//$(".newoverlay").hide();
	$scope.id = 1;
	
	
	$scope.progPercentage = 0;
	$(".cockpitWindow").hide();
	 $("#mydiv")
    .html('<object style="width:100%; height:600px;" data="http://10.10.223.67:8080/camunda/app/cockpit/default/#/processes"/>');
	$scope.loader=false;
	var json;

     function handleFileSelect(evt) {
           var files = evt.target.files; // FileList object

           // files is a FileList of File objects. List some properties.

     }

     document.getElementById('files').addEventListener('change',
                 handleFileSelect, false);

     function handleFileSelect(evt) {
           var files = evt.target.files; // FileList object

           // files is a FileList of File objects. List some properties.
           var output = [];
           for (var i = 0, f; f = files[i]; i++) {
                 var reader = new FileReader();

                 // Closure to capture the file information.
                 reader.onload = (function(theFile) {
                       return function(e) {
                             // console.log('e readAsText = ', e);
                             // console.log('e readAsText target = ', e.target);
                             try {
                                   $scope.json = JSON.parse(e.target.result);

                                   // alert('json global var has been set to parsed
                                   // json of this file here it is unevaled = \n' +
                                   // JSON.stringify(json));
                             } catch (ex) {
                                   alert('ex when trying to parse json = ' + ex);
                             }
                       }
                 })(f);
                 reader.readAsText(f);
           }

     }

     document.getElementById('files').addEventListener('change',
                 handleFileSelect, false);
     
     $scope.onClose = function(json) {
          $window.location.href = '#/dashboard';
     }
     
     $scope.closePopup = function() {
			$(".newoverlay").hide();
			$scope.errorRibbon = false;
			window.location.reload();
		}
     
		
 	$scope.runPreTest=function()
 	{
 		
 		$scope.showLoader = true;
 	$http({
 		method : 'GET',
 		url : '/runPreTest',
 		contentType : "application/json",
 	}).then(function(success) {
 		 $(".pageoverlay").hide();
 		 $scope.showLoader = false;
 		$scope.pretestresponse = 'Pre-test has been '+ success.data.response_body;
 		
 	}, function(err) {
 		 $scope.showLoader = false;
 	});
 }
 	
 	$scope.test = function(json) {
 		var d = document.getElementById($scope.id);
 		d.className = "active";
 		
 		/*var d = document.getElementById($scope.id);
 		d.className = "active";*/
 		//$("#updateDeviceSuccess").modal('show');
 		//$("#preTestSuccess").modal('show');
 		//$("#preTestFailure").modal('show');
 		//$("#updateDevice").modal('show');
 		//$("#preTestFinished").modal('show');
 		//$("#processSuccess").modal('show');
 		//$("#updateDevice").modal('show');
 		$scope.loader=true;
		
		document.getElementById('files')
		
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/process-definition/key/Device-Verification/submit-form',
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			$scope.loader=false;
			$scope.process_id=success.data.id;
			/*$scope.msg = 'Device has been updated succesfully. Running PreTest now';
			$scope.currentTask=true;
				$scope.titlemsg = 'Success';
				 $scope.styleclass = 'success';
				$("#MsgPopup").modal('show');*/
			$("#startProcess").modal('show');
		}, function(err) {
			
		});
	}
 	
 	$scope.getFirstTask =function()
	{  
 		
 	/*	var d = document.getElementById($scope.id);
 		d.className = "active";*/
		
		$http({
			method : 'GET',
			url : 'http://10.10.223.67:8080/engine-rest/task/?processInstanceId='+$scope.process_id,
			contentType : "application/json"
		}).then(function(success) {
			$scope.task_id=(success.data[0].id)
			$scope.firstTaskCompletion();
		}, function(err) {
		});
		
	}
 	
 	
 	$scope.firstTaskCompletion=function()
	{  
	   
 		
 		/*var d = document.getElementById($scope.id);
 		d.className = "active";*/
		$scope.loader=true;
		// $(".newoverlay").show();
	debugger;
	var json ={
		"variables": {
			"approver": {
				"value": "Demo",
				"type": "String"
			}
		}
	}
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete',
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			$scope.loader=false;
			 //$(".newoverlay").hide();
				$("#updateDeviceSuccess").modal('show');
				 var d = document.getElementById($scope.id);
					d.className = "previous visited";
					$scope.id = $scope.id + 1 ;
			 		var d = document.getElementById($scope.id);
			 		d.className = "active";
			/*$scope.msg = 'PreTest Finished.Please press NEXT to know the results of the Pre-Test';
			$scope.currentTask=false;
			$scope.nextTask=true;
				$scope.titlemsg = 'Success';
				 $scope.styleclass = 'success';
				$("#MsgPopup").modal('show');*/
			
		}, function(err) {
			
		});
	}
 	
 	
 	$scope.getCurrentTask =function()
	{   
 		

		$http({
			method : 'GET',
			url : 'http://10.10.223.67:8080/engine-rest/task/?processInstanceId='+$scope.process_id,
			contentType : "application/json"
		}).then(function(success) {
			$scope.task_id=(success.data[0].id)
			$scope.PT();
			//var url='http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete'
		}, function(err) {
		});
		
	}
 	
	$scope.getNextTask =function()
	{   
		debugger;
		var json ={
				"variables": {
					"approver": {
						"value": "Demo",
						"type": "String"
					}
				}
			}
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/?processInstanceId='+$scope.task_id,
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			var id;
			angular.forEach(success.data,function(value,key){
				angular.forEach(value,function(value1,key1){
					if(value1 ==  "UpdateDataBase"){
						id = key;
						$("#preTestSuccess").modal('show');
						
						/*$scope.msg = 'PreTest is Successful.Please NEXT to persist the details on the database';
						$scope.currentTask=false;
						$scope.nextTask=false;
						$scope.finalTask=true;
							$scope.titlemsg = 'Success';
							 $scope.styleclass = 'success';
							$("#MsgPopup").modal('show');*/
						
					}
					
					if(value1 ==  "RetriveConfiguration"){
						debugger
						id = key;
						/*$scope.msg = 'PreTest has failed.Please NEXT to get the latest Config Details from the database';
						$scope.currentTask=false;
						$scope.nextTask=false;
						$scope.finalTask=false;
						$scope.finalTaskfail=true;
							$scope.titlemsg = 'Success';
							 $scope.styleclass = 'success';
							$("#MsgPopup").modal('show');*/
						$("#preTestFailure").modal('show');
						
					}
					
					if(value1 ==  "Update Device Configuration"){
						id = key;
						/*$scope.msg = 'Latest Config Details have been retrived.Press Next to Update the old config Details onto the device';
						$scope.currentTask=false;
						$scope.nextTask=false;
						$scope.finalTask=false;
						$scope.nextTaskFail=true;
							$scope.titlemsg = 'Success';
							 $scope.styleclass = 'success';
							$("#MsgPopup").modal('show');*/
						$("#updateDevice").modal('show');
						
					}
					
				})
			});
			var d = document.getElementById($scope.id);
			d.className = "previous visited";
			$scope.id = $scope.id + 1 ;
	 		var d = document.getElementById($scope.id);
	 		d.className = "active";
			$scope.task_id=(success.data[id].id)
			console.log(success.data[id].name);
			//$scope.finalstep();
			//var url='http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete'
		}, function(err) {
		});
		
	}
	
	$scope.getNextTask1 =function()
	{   
		var d = document.getElementById($scope.id);
		d.className = "previous visited";
		$scope.id = $scope.id + 1 ;
 		var d = document.getElementById($scope.id);
 		d.className = "active";
	
		var json ={
				"variables": {
					"approver": {
						"value": "Demo",
						"type": "String"
					}
				}
			}
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/?processInstanceId='+$scope.task_id,
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			var id;
			angular.forEach(success.data,function(value,key){
				angular.forEach(value,function(value1,key1){
					if(value1 ==  "Update Device Configuration"){
						id = key;
					}
				})
			});
			$scope.task_id=(success.data[id].id)
			console.log(success.data[id].name);
			$scope.finalstep();
			//var url='http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete'
		}, function(err) {
		});
		
	}
	
	
	
	$scope.PT=function()
	{
		$scope.loader=true;
		// $(".newoverlay").show();
	debugger;
	var json ={
		"variables": {
			"approver": {
				"value": "Demo",
				"type": "String"
			}
		}
	}
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete',
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			$scope.loader=false;
			 //$(".newoverlay").hide();
				$("#preTestFinished").modal('show');
				var d = document.getElementById($scope.id);
				d.className = "previous visited";
				$scope.id = $scope.id + 1 ;
		 		var d = document.getElementById($scope.id);
		 		d.className = "active";
			/*$scope.msg = 'PreTest Finished.Please press NEXT to know the results of the Pre-Test';
			$scope.currentTask=false;
			$scope.nextTask=true;
				$scope.titlemsg = 'Success';
				 $scope.styleclass = 'success';
				$("#MsgPopup").modal('show');*/
			
		}, function(err) {
			
		});
	}

	
	$scope.finalstep=function()
	{  
		
	var json ={
		"variables": {
			"approver": {
				"value": "Demo",
				"type": "String"
			}
		}
	}
		console.log("in finalstep");
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete',
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
			$("#processSuccess").modal('show');
			var d = document.getElementById($scope.id);
			d.className = "previous visited";
			$scope.id = $scope.id + 1 ;
	 		var d = document.getElementById($scope.id);
	 		d.className = "active";
			/*$scope.msg = 'Data has been saved successfully.Process Ends';
			$scope.currentTask=false;
			$scope.nextTask=false;
			$scope.finalTask=false;
			$scope.closeButton=true;
			$scope.finalTaskfail=false;
				$scope.titlemsg = 'Success';
				 $scope.styleclass = 'success';
				$("#MsgPopup").modal('show');*/
		}, function(err) {
			console.log(err);
			
		});
	}
	
	
	$scope.finalstep1=function()
	{  
		
	
		$("#preTestFailure").modal('hide');
	var json ={
		"variables": {
			"approver": {
				"value": "Demo",
				"type": "String"
			}
		}
	}
		console.log("in finalstep1");
		$http({
			method : 'POST',
			url : 'http://10.10.223.67:8080/engine-rest/task/'+$scope.task_id+'/complete',
			contentType : "application/json",
			data : angular.toJson(json)
		}).then(function(success) {
				$("#updateDevice").modal('show');
				var d = document.getElementById($scope.id);
				d.className = "previous visited";
				$scope.id = $scope.id + 1 ;
		 		var d = document.getElementById($scope.id);
		 		d.className = "active";
			/*$scope.msg = 'Latest Config Details have been retrived.Press Next to Update the old config Details onto the device';
			$scope.currentTask=false;
			$scope.nextTask=false;
			$scope.finalTask=false;
			$scope.closeButton=false;
			$scope.nextTaskFail=true;
				$scope.titlemsg = 'Success';
				 $scope.styleclass = 'success';
				$("#MsgPopup").modal('show');*/
			
		}, function(err) {
			console.log(err);
			
		});
	}
	$scope.showCockpitWindow=function()
	{   
		$(".cockpitWindow").show();
		$scope.loader=false;
		debugger;
		//$("#"+id).modal('hide');		
	}
	$scope.closeCockpitWindow=function()
	{
		debugger;
		$(".cockpitWindow").hide();
		//$("#"+id).modal('show');	
	}
     
     
});