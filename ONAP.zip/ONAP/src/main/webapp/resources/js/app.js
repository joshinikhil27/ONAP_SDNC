var app = angular.module('App',['nvd3ChartDirectives','ui.router']);
