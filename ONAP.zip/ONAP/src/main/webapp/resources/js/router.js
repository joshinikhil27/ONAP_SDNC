app.config(function($stateProvider, $urlRouterProvider) {
    $urlRouterProvider.otherwise('/dashboard');
    $stateProvider
        .state('dashboard', {
            url: '/dashboard',
            templateUrl: 'resources/pages/dashboard.jsp',
            controller : 'dashboardCtrl'
        })
        .state('persistedData', {
            url: '/persistedData',
            templateUrl: 'resources/pages/data-persist.jsp',
            controller : 'persistCtrl'
        })
        .state('restartinfo', {
            url: '/restartinfo',
            templateUrl: 'resources/pages/restartinfo.jsp',
            controller : 'restartinfoCtrl'
        })
        .state('presistData', {
            url: '/presistData',
            templateUrl: 'resources/pages/presistData.jsp',
            controller : 'presistDataCtrl'
        })
        .state('preTest', {
            url: '/preTest',
            templateUrl: 'resources/pages/preTest.jsp',
            controller : 'preTestCtrl'
        })
        .state('versionHistory', {
            url: '/versionHistory',
            templateUrl: 'resources/pages/versionHistory.jsp',
            controller : 'versionHistoryCtrl'
        })
        .state('versionComp', {
            url: '/versionComp',
            templateUrl: 'resources/pages/versionComp.jsp',
            controller : 'versionCompCtrl'
        })
        .state('versionInfo', {
            url: '/versionInfo',
            templateUrl: 'resources/pages/VersionInfo.jsp',
            controller : 'versionHistoryCtrl'
        })
        .state('versionCompNew', {
            url: '/versionCompNew',
            templateUrl: 'resources/pages/versionCompNew.jsp',
            controller : 'versionHistoryCtrl'
        })
        .state('eventList', {
            url: '/eventList',
            templateUrl: 'resources/pages/eventList.jsp',
            controller : 'eventListCtrl'
        });

});