package com.microservices.service;

import com.microservices.web.rest.model.RestartInfoDetailsRestModel;

public interface RestartInfoDetailsService {

	String addRestartInfoDetails(RestartInfoDetailsRestModel router);

}
