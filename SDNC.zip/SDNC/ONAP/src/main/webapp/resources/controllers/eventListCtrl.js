app.controller('eventListCtrl',function($scope,$http,$rootScope){
	$scope.getContextPath = function() {
		return window.location.pathname.substring(0,
                window.location.pathname.lastIndexOf("/"));
	};
	var contextPath = $scope.getContextPath();
	$scope.tableData=true;
	$scope.noData=true;
	$scope.srcEventList=false;
	$scope.srcEventList=false;
	
	$scope.onTopicChange = function () {
		var basePath=$scope.getContextPath();
		var id=$scope.topicList.split('.')[1];
		console.log(id);
	   $http({
				method : 'POST',
				url : basePath +"/event/getEventsForTopic/"+ id
			}).success(function(data, status, headers, config) {
				console.log(JSON.stringify(data));
				  $scope.events  = data.response_body.events;
				  if($scope.events !=null)
					  $scope.eventList=true;
				  else
					  $scope.eventList=false;	
	
			}).error(function(data, status, headers, config) {
				console.log('Error occurred '+data);
			});
	   
	   $http({
			method : 'POST',
			url : basePath +"/event/getSrcEventsForTopic/"+ id
		}).success(function(data, status, headers, config) {
			console.log(JSON.stringify(data));
			  $scope.srcevents  = data.response_body.events;
			  if($scope.srcevents !=null)
				  $scope.srcEventList=true;
			  else
				  $scope.srcEventList=false;

		}).error(function(data, status, headers, config) {
			console.log('Error occurred '+data);
		});
	
	};
	
	$scope.onBodyLoad = function () {
		var basePath=$scope.getContextPath();
		//var id=$scope.topicList.split('.')[1];
		  $scope.topicList = 'unauthenticated.SEC_MEASUREMENT_OUTPUT';
		console.log();
		
	   $http({
				method : 'POST',
				url : basePath +"/event/getEventsForTopic/SEC_MEASUREMENT_OUTPUT"
			}).success(function(data, status, headers, config) {
				console.log(JSON.stringify(data));
				  $scope.events  = data.response_body.events;
				  if($scope.events !=null)
					  $scope.tableData=false;
				  else
					  $scope.noData=false;
	
			}).error(function(data, status, headers, config) {
				console.log('Error occurred '+data);
			});
	   
	   
	   
	   $http({
			method : 'POST',
			url : basePath +"/event/getSrcEventsForTopic/SEC_MEASUREMENT_OUTPUT"
		}).success(function(data, status, headers, config) {
			console.log(JSON.stringify(data));
			  $scope.srcevents  = data.response_body.events;
			  if($scope.srcevents !=null)
				  $scope.srcEventList=true;
			  else
				  $scope.srcEventList=false;	

		}).error(function(data, status, headers, config) {
			console.log('Error occurred '+data);
		});
	
	};
	
	$scope.onBodyLoad();
});