app.controller('presistDataCtrl',function($scope,$http,$filter,$rootScope,$state){
	$scope.test = function(json) {
        debugger;
        document.getElementById('files')
        console.log("JSON" + angular.toJson(json))
        debugger
        $http({
              method : 'POST',
              url : 'http://10.10.223.67:8282/addRouterConfigDetails',
              contentType : "application/json",
              data : angular.toJson(json)
        }).then(function(success) {
              console.log("Entered");
              $("#myModal").modal('show');
              
              
        }, function(err) {
              console.log("error");
        });
	}
	
	 var json;

     function handleFileSelect(evt) {
           var files = evt.target.files; // FileList object

           // files is a FileList of File objects. List some properties.

     }

     document.getElementById('files').addEventListener('change',
                 handleFileSelect, false);

     function handleFileSelect(evt) {
           var files = evt.target.files; // FileList object

           // files is a FileList of File objects. List some properties.
           var output = [];
           for (var i = 0, f; f = files[i]; i++) {
                 var reader = new FileReader();

                 // Closure to capture the file information.
                 reader.onload = (function(theFile) {
                       return function(e) {
                             // console.log('e readAsText = ', e);
                             // console.log('e readAsText target = ', e.target);
                             try {
                                   $scope.json = JSON.parse(e.target.result);

                                   // alert('json global var has been set to parsed
                                   // json of this file here it is unevaled = \n' +
                                   // JSON.stringify(json));
                             } catch (ex) {
                                   alert('ex when trying to parse json = ' + ex);
                             }
                       }
                 })(f);
                 reader.readAsText(f);
           }

     }

     document.getElementById('files').addEventListener('change',
                 handleFileSelect, false);
     
     $scope.onClose = function(json) {
           var origin = window.location.origin;
           console.log("ORIGIN"+origin);
       window.location.href = origin+'/home';
     }
});