package com.microservices;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.logging.Logger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.microservices.dao.model.Router;
import com.microservices.dao.model.RouterConfigDetails;
import com.microservices.dao.model.ShellScriptLocation;
import com.microservices.service.FileLocationService;
import com.microservices.service.RouterConfigDetailsService;
import com.microservices.web.rest.model.Bgp;
import com.microservices.web.rest.model.ConfigDetailsRestModel;
import com.microservices.web.rest.model.Ipsla;
import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.Neighbors;
import com.microservices.web.rest.model.Networks;
import com.microservices.web.rest.model.Ospf;
import com.microservices.web.rest.model.ProtocolModel;
import com.microservices.web.rest.model.RouterConfigModel;
import com.microservices.web.rest.model.RouterWebModel;

@Controller
public class WelcomeController {
	private static final Logger logger = Logger.getLogger(WelcomeController.class.getName());
	@Autowired
	private RouterConfigDetailsService routerConfigDetailsService;

	// inject via application.properties
	@Value("${welcome.message:test}")
	private String message = "Hello World";

	@CrossOrigin
	@RequestMapping(value = "/home")
	public String gotoHomePage(Map<String, List<Router>> model) {
		logger.info("HOMEPAGE");
		return "index";
	}

	// Listing all the Routers present
	@CrossOrigin
	@RequestMapping(value = "/listRouters")
	@ResponseBody
	public JsonResponse<Map<String, List<String>>> gotoViewRouters() {

		JsonResponse<Map<String, List<String>>> response = new JsonResponse<Map<String, List<String>>>();
		List<String> routerNamesList = new ArrayList<>();
		List<Router> allRouters = routerConfigDetailsService.getAllRouters();
		if (allRouters.size() != 0) {
			for (Router router : allRouters) {
				String router_name = router.getRouter_name();
				routerNamesList.add(router_name);
			}
			Map<String, List<String>> responseBody = new HashMap<String, List<String>>();

			responseBody.put("routerList", routerNamesList);
			response.setResponseBody(responseBody);
			response.setStatus(Boolean.TRUE);
			response.setResponseDetail("Fetched all the available routers");
		} else {
			response.setStatus(Boolean.FALSE);
			response.setResponseDetail("No Routers Present");
		}

		return response;
	}

	// List Details for a specific Router
	@CrossOrigin
	@RequestMapping(value = "/routerDetails/{name}")
	@ResponseBody
	public JsonResponse<Map<String, List<ConfigDetailsRestModel>>> viewRouterDetails(@PathVariable String name) {

		JsonResponse<Map<String, List<ConfigDetailsRestModel>>> response = new JsonResponse<Map<String, List<ConfigDetailsRestModel>>>();
		response.setResponseBody(null);

		Router routerDetails = routerConfigDetailsService.getRouterConfigDetails(name);
		if (routerDetails != null) {
			List<RouterConfigDetails> routerConfigDetailsListObj = routerDetails.getRouterConfigDetailsObj();

			Collections.sort(routerConfigDetailsListObj);

			Map<String, List<RouterConfigDetails>> map = new LinkedHashMap<String, List<RouterConfigDetails>>();
			List<RouterConfigDetails> routerConfigDetailsList = null;
			for (RouterConfigDetails rcd : routerConfigDetailsListObj) {
				if (map.containsKey(rcd.getDate().toString())) {
					map.get(rcd.getDate().toString()).add(rcd);
				} else {
					if (map.size() == 2) {
						break;
					}
					List<RouterConfigDetails> details = new ArrayList<RouterConfigDetails>();
					details.add(rcd);
					map.put(rcd.getDate().toString(), details);
				}
			}
			Map<String, List<ConfigDetailsRestModel>> map2 = new LinkedHashMap<String, List<ConfigDetailsRestModel>>();
			String r = "version";
			int i = 0;
			for (Entry<String, List<RouterConfigDetails>> e : map.entrySet())
			{
				map2.put(r + ++i, RouterConfigDetails.fromEntityToModel(e.getValue()));
			}
			List<ConfigDetailsRestModel> list1 = map2.get("version1");
			List<ConfigDetailsRestModel> list2 = map2.get("version2");
			
			response.setStatus(Boolean.TRUE);
			response.setErrorCode("SUCCESS");
			response.setResponseDetail("Retrieved the Router Config Info successfully.");
			response.setResponseBody(map2);
		} else {
			response.setStatus(Boolean.TRUE);
			response.setErrorCode("ERROR");
			response.setResponseDetail("No Router Configuration Information Available");
			// response.setResponseBody(map2);
		}
		return response;
	}

	// List Details for a specific Router
		@CrossOrigin
		@RequestMapping(value = "/viewVersionDetails/{name}/{version1}/{version2}/")
		@ResponseBody
		public JsonResponse<Map<String, List<ConfigDetailsRestModel>>> viewVersionDetails(@PathVariable String name,@PathVariable String version1,@PathVariable String version2 ) {

			
			
			JsonResponse<Map<String, List<ConfigDetailsRestModel>>> response = new JsonResponse<Map<String, List<ConfigDetailsRestModel>>>();
			response.setResponseBody(null);

			Router routerDetails = routerConfigDetailsService.getRouterConfigDetails(name);
			if (routerDetails != null) {
				List<RouterConfigDetails> routerConfigDetailsListObj = routerDetails.getRouterConfigDetailsObj();

				//Collections.sort(routerConfigDetailsListObj);

				Map<String, List<RouterConfigDetails>> omap1= new LinkedHashMap<String, List<RouterConfigDetails>>();
				Map<String, List<RouterConfigDetails>> omap2= new LinkedHashMap<String, List<RouterConfigDetails>>();
					
				List<RouterConfigDetails> version1Details = new ArrayList<RouterConfigDetails>();
				List<RouterConfigDetails> version2Details = new ArrayList<RouterConfigDetails>();
				List<RouterConfigDetails> versionList = new ArrayList<RouterConfigDetails>();
				for (RouterConfigDetails routerConfigDetails : routerConfigDetailsListObj) {
					if(routerConfigDetails.getVersion_id().equals(version1))
					{
						version1Details.add(routerConfigDetails);
					}
					else if(routerConfigDetails.getVersion_id().equals(version2))
					{
						version2Details.add(routerConfigDetails);
					}
				}
				omap1.put("version1",version1Details);
				omap2.put("version2",version2Details);
				Map<String, List<ConfigDetailsRestModel>> map2 = new LinkedHashMap<String, List<ConfigDetailsRestModel>>();
				String r = "version";
				int i = 0;
				for (Entry<String, List<RouterConfigDetails>> e : omap1.entrySet())
				{
					map2.put("version1", RouterConfigDetails.fromEntityToModel(e.getValue()));
					
					
				}
				for (Entry<String, List<RouterConfigDetails>> e : omap2.entrySet())
				{
					map2.put("version2", RouterConfigDetails.fromEntityToModel(e.getValue()));
					
					
				}
				
				response.setStatus(Boolean.TRUE);
				response.setErrorCode("SUCCESS");
				response.setResponseDetail("Retrieved the Router Config Info successfully.");
				response.setResponseBody(map2);
			} else {
				response.setStatus(Boolean.TRUE);
				response.setErrorCode("ERROR");
				response.setResponseDetail("No Router Configuration Information Available");
				// response.setResponseBody(map2);
			}
			return response;
		}

	
// Save Details in MongoDB
		@RequestMapping(value = "/addRouterConfigDetails", method = org.springframework.web.bind.annotation.RequestMethod.POST,produces = {
		"application/json" }, consumes = { "application/json" })
		@ResponseBody
		public JsonResponse<RouterConfigModel> addRouterConfigDetails(@RequestBody RouterConfigModel request)
				 {
			System.out.println("Add Router Config Details STARTED");
			
			JsonResponse<RouterConfigModel> response = null;

			response = routerConfigDetailsService.add(request);
			
			System.out.println("Add Router Config Details ENDED");
			
			return response;

		}

	
	
// Save Details in MongoDB
	/*@CrossOrigin
	@RequestMapping(value = "/addRouterConfigDetails", method = org.springframework.web.bind.annotation.RequestMethod.POST)
	@ResponseBody
	public JsonResponse<ConfigDetailsRestModel> addRouterConfigDetails(@RequestBody String router)
			 {
		/*router = router.replaceAll("\n", "\\n");
		router = router.replaceAll("=",":");
		String replaceEquals = router.replace("=",":");
		String replaceAll = replaceEquals.replace("{","{\"");
		String finalstr = replaceAll.replace(":","\":");
		System.out.println(finalstr);
		
		System.out.println("Add Router Config Details STARTED");
		
		JsonResponse<ConfigDetailsRestModel> response = null;

		ConfigDetailsRestModel convertedJson = this.convertJson(finalstr);
		response = routerConfigDetailsService.addRouterConfigDetails(convertedJson);
		
		System.out.println("Add Router Config Details ENDED");
		
		return response;

	}*/
	
	
	
	
	// Convert JSON
		public ConfigDetailsRestModel convertJson(
				Router request) {
			
		System.out.println("JSON Converstion STARTED");
			
			JSONObject jsonObj = new JSONObject(request);
            Iterator<String> keysItr = jsonObj.keys();
            
            ConfigDetailsRestModel model=new ConfigDetailsRestModel();
            List<ProtocolModel> protocolmodelList= new ArrayList<ProtocolModel>();
            List<Object> protocolList= new ArrayList();            
            while(keysItr.hasNext()) 
            {
            	String key = keysItr.next();
            	model.setRouter(key);
            	Object value = jsonObj.get(key).toString();
                
                JSONObject protocol = new JSONObject(value.toString());
               Iterator<String> protocolkeys = protocol.keys();
               
               while(protocolkeys.hasNext()) 
               {
            	   String protocol_name = protocolkeys.next();
                
                
                if(("ipsla").equals(protocol_name))
                {
                	JSONArray  ipslavalueList = (JSONArray) protocol.get(protocol_name);
                	
                	
                
                		for (int i = 0; i < ipslavalueList.length(); i++) {
                            JSONObject objects = ipslavalueList.getJSONObject(i);
                            ProtocolModel protocolmodel= new ProtocolModel();
                                protocolmodel.setCos_entry_number(objects.get("cos-entry-number").toString());
                                protocolmodel.setProtocol_name(protocol_name);
                                protocolmodel.setDestination_address(objects.get("destination-address").toString());
                                protocolmodel.setSource_address(objects.get("source-address").toString());
                                protocolmodel.setCustomer_name(objects.get("customer-name").toString());
                                protocolmodelList.add(protocolmodel); 
                            
                        }
                }
                if(("bgp").equals(protocol_name))
                {
                	ProtocolModel protocolmodel= new ProtocolModel();
                	protocolmodel.setProtocol_name(protocol_name);
                	JSONObject  bgpvalue = (JSONObject )protocol.get(protocol_name);
                    
                	protocolmodel.setAs_number(bgpvalue.get("as-number").toString());
                	protocolmodel.setRouter_id(bgpvalue.get("router-id").toString());
                
                
                JSONObject neighbors =(JSONObject) bgpvalue.get("neighbors");
                HashMap<String, String> neighbormap = new HashMap<String, String>();
                String neigbor_as_number = neighbors.get("as-number").toString();
                String neigbor_peer_ip = neighbors.get("peer-ip").toString();
                
                neighbormap.put("as_number", neigbor_as_number);
                neighbormap.put("peer_ip", neigbor_peer_ip);
                protocolmodel.setNeighbors(neighbormap);
                protocolmodel.setPeer_ip(neigbor_peer_ip);
                System.out.println("Peer"+neigbor_peer_ip);
                protocolmodelList.add(protocolmodel);
                }
                if(("ospf").equals(protocol_name))
                {
                	ProtocolModel protocolmodel= new ProtocolModel();
                	protocolmodel.setProtocol_name(protocol_name);
                	JSONObject  ospfvalue = (JSONObject )protocol.get(protocol_name);
                	protocolmodel.setProcess_id(ospfvalue.get("process-id").toString());
                	
                	
                	JSONObject networks =(JSONObject) ospfvalue.get("networks");
                    HashMap<String, String> networksmap = new HashMap<String, String>();
                    String network_subnet_ip = networks.get("subnet-ip").toString();
                    String network_area_id = networks.get("area-id").toString();
                    
                    networksmap.put("subnet_ip", network_subnet_ip);
                    networksmap.put("area_id", network_area_id);
                    protocolmodel.setNetworks(networksmap);
                    protocolmodelList.add(protocolmodel);
                	
                }
                
               }

            }
			
			
			model.setProtocol(protocolmodelList);
			JsonResponse<ConfigDetailsRestModel> response = null;
			System.out.println("Model : " + model);

			System.out.println("JSON Converstion ENDED");
			
			return model;

		}
	

	// Get Latest Router Config Information
/*	@CrossOrigin
	@RequestMapping(value = "/getLatestConfigDetails/{name}")
	@ResponseBody
	public JsonResponse<Map<String, List<RouterConfigDetails>>> getLatestConfigDetails(@PathVariable String name) {
		System.out.println("IN RETRIVE CONFG JAVA METHOD");
		logger.info("INSIDE RETRIVE CONFIG DETAILS");
		JsonResponse<Map<String, List<RouterConfigDetails>>> response = new JsonResponse<Map<String, List<RouterConfigDetails>>>();
		response.setResponseBody(null);

		Router routerConfigDetails = routerConfigDetailsService.getRouterConfigDetails(name);
		List<RouterConfigDetails> routerConfigDetailsListObj = routerConfigDetails.getRouterConfigDetailsObj();
		// List<RouterConfigDetails> newList = new
		// ArrayList<RouterConfigDetails>() ;

		Collections.sort(routerConfigDetailsListObj);

		Map<String, List<RouterConfigDetails>> map = new LinkedHashMap<String, List<RouterConfigDetails>>();
		List<RouterConfigDetails> routerConfigDetailsList = null;
		for (RouterConfigDetails rcd : routerConfigDetailsListObj) {
			if (map.containsKey(rcd.getDate().toString())) {
				map.get(rcd.getDate().toString()).add(rcd);
			} else {
				if (map.size() == 1) {
					break;
				}
				List<RouterConfigDetails> details = new ArrayList<RouterConfigDetails>();
				details.add(rcd);
				map.put(rcd.getDate().toString(), details);
			}
		}
		Map<String, List<RouterConfigDetails>> map2 = new LinkedHashMap<String, List<RouterConfigDetails>>();
		String r = "version";
		int i = 0;
		for (Entry<String, List<RouterConfigDetails>> e : map.entrySet())
			map2.put(r + ++i, e.getValue());

		response.setStatus(Boolean.TRUE);
		response.setErrorCode("SUCCESS");
		response.setResponseDetail("Retrieved the Router Config Info successfully.");
		response.setResponseBody(map2);

		return response;

	}*/
		
		

		// Get Latest Router Config Information
		@CrossOrigin
		@RequestMapping(value = "/getLatestConfigDetails/{name}")
		@ResponseBody
		public RouterConfigModel getLatestConfigDetails(@PathVariable String name) {
			System.out.println("IN RETRIVE CONFG JAVA METHOD");
			logger.info("INSIDE RETRIVE CONFIG DETAILS");

			Router routerConfigDetails = routerConfigDetailsService.getRouterConfigDetails(name);
			List<RouterConfigDetails> routerConfigDetailsListObj = routerConfigDetails.getRouterConfigDetailsObj();
			String version_id = null ;
			RouterConfigModel model= new RouterConfigModel();
			RouterWebModel routerwebmodel= new RouterWebModel();
			List<Ipsla> ipslaList=new ArrayList<Ipsla>();
			
			//for (RouterConfigDetails routerConfigDetailsObj : routerConfigDetailsListObj) {
			
			//find the latest version
			for (int i = 1; i < routerConfigDetailsListObj.size(); i++) {
				RouterConfigDetails routerConfigDetailsObj = routerConfigDetailsListObj.get(routerConfigDetailsListObj.size()-1);
				version_id = routerConfigDetailsObj.getVersion_id();
			}
			System.out.println("Latest version is "+version_id);
			
			for (int j = 0;j < routerConfigDetailsListObj.size(); j++) {
				RouterConfigDetails routerConfigDetailsObj = routerConfigDetailsListObj.get(j);
				
				if(routerConfigDetailsObj.getVersion_id().equals(version_id))
				{
					System.out.println("IN JAJAJSJSJA");
				if("bgp".equals(routerConfigDetailsObj.getProtocol()))
				{
					Bgp bgp=new Bgp();
					Neighbors neighbors= new Neighbors();
					bgp.setAsNumber(routerConfigDetailsObj.getAs_number());
					bgp.setRouterId(routerConfigDetailsObj.getRouter_id());
					
					HashMap<String, String> neighborsmap = routerConfigDetailsObj.getNeighbors();
					
					String peerIp = neighborsmap.get("peer_ip");
					String neigbor_asNumber = neighborsmap.get("as_number");
					neighbors.setAsNumber(neigbor_asNumber);
					neighbors.setPeerIp(peerIp);

					bgp.setNeighbors(neighbors);
					routerwebmodel.setBgp(bgp);
				}
				if ("ospf".equals(routerConfigDetailsObj.getProtocol())) {
					Ospf ospf = new Ospf();
					Networks networks = new Networks();
					ospf.setProcessId(routerConfigDetailsObj.getProcess_id());
					
					HashMap<String, String> networksmap = routerConfigDetailsObj.getNetworks();
					
					String subnet_ip = networksmap.get("subnet_ip");
					String area_id = networksmap.get("area_id");
					
					networks.setAreaId(area_id);
					networks.setSubnetIp(subnet_ip);
					
					ospf.setNetworks(networks);
					routerwebmodel.setOspf(ospf);
				}
				if ("ipsla".equals(routerConfigDetailsObj.getProtocol())) 
				{
					Ipsla ipsla = new Ipsla();
					
					ipsla.setCosEntryNumber(routerConfigDetailsObj.getCos_entry_number());
					ipsla.setCustomerName(routerConfigDetailsObj.getCustomer_name());
					ipsla.setDestinationAddress(routerConfigDetailsObj.getDestination_address());
					ipsla.setSourceAddress(routerConfigDetailsObj.getSource_address());
					ipslaList.add(ipsla);
				}
				routerwebmodel.setIpsla(ipslaList);
				model.setRouter(routerwebmodel);
			}
			}
			
			return model;
			
		}	

	// Update Device Configuration
	@CrossOrigin
	@RequestMapping(value = "/updateDeviceConfiguration", method = org.springframework.web.bind.annotation.RequestMethod.PUT)
	@ResponseBody
	public JsonResponse<ConfigDetailsRestModel> updateDeviceConfiguration(
			@RequestBody RouterConfigModel request) {
		logger.info("UPDATE device configuration");
		System.out.println("UPDATE device configuration");
		JsonResponse<ConfigDetailsRestModel> response = new JsonResponse<ConfigDetailsRestModel>();

		response.setStatus(Boolean.TRUE);
		response.setErrorCode("SUCCESS");
		response.setResponseDetail("Device Configuration Updated Succesfully");
		return response;

	}

	// Upload File
	@RequestMapping(value = "/upload")
	@CrossOrigin
	public void uploadFile() {
	}

	@Autowired
	FileLocationService fileLocationService;

	// Listing File Location
	@CrossOrigin
	@RequestMapping(value = "/runPreTest", method = RequestMethod.POST, headers = "Accept=application/json")
	@ResponseBody
	public JsonResponse<StringBuffer> runPreTest() {
		
		logger.info("PRE TEST STARTED");

		JsonResponse<StringBuffer> response = new JsonResponse<StringBuffer>();
		response.setResponseBody(null);
		ShellScriptLocation fileLocation = fileLocationService.getFileLocation();
		String file_location = fileLocation.getFile_location();
		StringBuffer testResponse = readFile(file_location);
		System.out.println("TestResponse" + testResponse);
		response.setStatus(Boolean.TRUE);
		response.setErrorCode(testResponse.toString());
		response.setResponseDetail("Pre-test	" + testResponse);
		response.setResponseBody(testResponse);

		logger.info("PRE TEST ENDED");
		
		return response;
	}

	public StringBuffer readFile(String file_location) {

		StringBuffer test = new StringBuffer("Success");
		try {
			BufferedReader br = null;
			Runtime runtime = Runtime.getRuntime();
			File folder = new File(file_location);
			File[] listOfFiles = folder.listFiles();
			System.out.println("File Location" + file_location);
			for (File file : listOfFiles) {
				if (file.isFile()) {
					System.out.println(file.getName());
					Process process = Runtime.getRuntime().exec(file_location + file.getName());

					InputStream is = process.getInputStream();
					InputStreamReader isr = new InputStreamReader(is);
					br = new BufferedReader(isr);
					String line;

					System.out.printf("Output of running the command is:");

					while ((line = br.readLine()) != null) {
						System.out.println(line);
						if (line.contains("Request timed out")) {
							test = new StringBuffer("Failed");
							break;
						}

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return test;
	}
	
	
	@CrossOrigin
	@RequestMapping(value = "/getVersionHistory/{name}")
	@ResponseBody
	public JsonResponse<List<RouterConfigDetails>> getVersionHistory(@PathVariable String name) {
	
		JsonResponse<List<RouterConfigDetails>> response = new JsonResponse<List<RouterConfigDetails>>();
		List<RouterConfigDetails> routerConfigDetailsList = null;
		Router routerDetails = routerConfigDetailsService.getRouterConfigDetails(name);
		if (routerDetails != null) {
			routerConfigDetailsList= routerDetails.getRouterConfigDetailsObj();
			System.out.println("AA");
	}
		response.setStatus(Boolean.TRUE);
		response.setErrorCode("SUCCESS");
		response.setResponseDetail("Version History Fetched Succesfully");
		response.setResponseBody(routerConfigDetailsList);
		return response;
	}
}
