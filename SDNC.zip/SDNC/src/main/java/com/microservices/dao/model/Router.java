package com.microservices.dao.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Router")
public class Router {

	@Id
	String router_id;

	String router_name;
	List<RouterConfigDetails> routerConfigDetailsObj;
	
	

	public String getRouter_id() {
		return router_id;
	}



	public void setRouter_id(String router_id) {
		this.router_id = router_id;
	}



	public String getRouter_name() {
		return router_name;
	}



	public void setRouter_name(String router_name) {
		this.router_name = router_name;
	}



	public List<RouterConfigDetails> getRouterConfigDetailsObj() {
		return routerConfigDetailsObj;
	}



	public void setRouterConfigDetailsObj(List<RouterConfigDetails> routerConfigDetailsObj) {
		this.routerConfigDetailsObj = routerConfigDetailsObj;
	}



	@Override
	public String toString() {
		return "Router [router_id=" + router_id + ", router_name=" + router_name+"]";
	}

}
