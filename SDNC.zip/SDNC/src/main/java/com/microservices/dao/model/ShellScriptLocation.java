package com.microservices.dao.model;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ShellScriptLocation")
public class ShellScriptLocation {

	@Id
	String id;

	String file_location;
	
	
	

	public String getId() {
		return id;
	}




	public void setId(String id) {
		this.id = id;
	}




	public String getFile_location() {
		return file_location;
	}




	public void setFile_location(String file_location) {
		this.file_location = file_location;
	}




	@Override
	public String toString() {
		return "ShellScriptLocation [id=" + id + ", file_location=" + file_location+"]";
	}

}
