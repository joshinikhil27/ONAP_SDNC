package com.microservices.dao;

import com.microservices.dao.model.RouterConfigDetails;
import com.microservices.exceptions.SequenceException;

public interface SequenceDao {

	long getRouterConfigDetailsNextSequenceId(String key) throws SequenceException;
	
	long getRouterNextSequenceId(String key) throws SequenceException;
	
	float getVersion(String key) throws SequenceException;

//	RouterConfigDetails getDepartmentFor(Long valueOf);
}
