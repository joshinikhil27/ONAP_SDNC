package com.microservices.repositories;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservices.dao.model.ShellScriptLocation;

public interface FileLocationRepository extends MongoRepository<ShellScriptLocation, String> {

	
}
