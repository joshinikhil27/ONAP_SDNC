package com.microservices.repositories;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.microservices.dao.model.Router;
import com.microservices.dao.model.RouterConfigDetails;

public interface RouterConfigDetailsRepository extends MongoRepository<Router, String> {

	void save(List<RouterConfigDetails> routerConfigDetailsList);
	
	//void find(Router routerObj);

}
