package com.microservices.service;

import java.util.List;

import com.microservices.dao.model.ShellScriptLocation;

public interface FileLocationService {


	ShellScriptLocation getFileLocation();
	
	
}
