package com.microservices.service;

import java.util.List;

import com.microservices.dao.model.Router;
import com.microservices.web.rest.model.ConfigDetailsRestModel;
import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.RouterConfigModel;

public interface RouterConfigDetailsService {

	//String saveRouterConfigDetails(List<String> args);

	JsonResponse<RouterConfigModel> add(RouterConfigModel request);
	
	JsonResponse<ConfigDetailsRestModel> addRouterConfigDetails(ConfigDetailsRestModel router);

	//JsonResponse<RouterConfigDetailsRestModel> addRouterConfigDetailsnew(ConfigDetailsRestModel model);
	Router getRouterConfigDetails(String name);

	List<Router> getAllRouters();
	
	List<String> getVersionHistory();
}
