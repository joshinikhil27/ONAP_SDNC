package com.microservices.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservices.dao.model.ShellScriptLocation;
import com.microservices.repositories.FileLocationRepository;

@Service
public class FileLocationServiceImpl implements FileLocationService {

	@Autowired
	private FileLocationRepository fileLocationRepo;

	@Override
	public ShellScriptLocation getFileLocation() {

		List<ShellScriptLocation> findAll = fileLocationRepo.findAll();
		ShellScriptLocation shellScriptLocation = findAll.get(0);

		return shellScriptLocation;
	}

}
