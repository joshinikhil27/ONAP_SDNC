package com.microservices.service;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.microservices.dao.SequenceDao;
import com.microservices.dao.model.Router;
import com.microservices.dao.model.RouterConfigDetails;
import com.microservices.repositories.RouterConfigDetailsRepository;
import com.microservices.web.rest.model.Bgp;
import com.microservices.web.rest.model.ConfigDetailsRestModel;
import com.microservices.web.rest.model.Ipsla;
import com.microservices.web.rest.model.JsonResponse;
import com.microservices.web.rest.model.Neighbors;
import com.microservices.web.rest.model.Networks;
import com.microservices.web.rest.model.Ospf;
import com.microservices.web.rest.model.ProtocolModel;
import com.microservices.web.rest.model.RouterConfigModel;

@Service
public class RouterConfigDetailsServiceImpl implements RouterConfigDetailsService {

	private static final String ROUTER_CONFIG_VERSION = "router_config_sequence";
	private static final String VERSION = "version";
	private static final String ROUTER = "router_sequence";

	@Autowired
	private RouterConfigDetailsRepository routerConfigDetailsRepo;

	@Autowired
	private SequenceDao seqDao;

	@Override
	public List<Router> getAllRouters() {

		List<Router> routerList = routerConfigDetailsRepo.findAll();

		// routerList.forEach(router -> System.out.println("RouterConfigDetails
		// : "+router.toString()));
		return routerList;
	}

	@Override
	public Router getRouterConfigDetails(String name) {
		List<Router> routerList = getAllRouters();
		Router routerDetails = null;
		for (Router routerDetailsObj : routerList) {
			if (routerDetailsObj.getRouter_name().equalsIgnoreCase(name)) {
				routerDetails = routerDetailsObj;
				break;
			}
		}
		return routerDetails;

	}

	@Override
	public JsonResponse<ConfigDetailsRestModel> addRouterConfigDetails(ConfigDetailsRestModel router) {

		JsonResponse<ConfigDetailsRestModel> response = new JsonResponse<ConfigDetailsRestModel>();
		response.setResponseBody(null);
		try {
			String router_name = router.getRouter();
			List<ProtocolModel> protocolList = router.getProtocol();
			String version = String.valueOf(seqDao.getVersion(VERSION));

			Router routerObj = this.getRouterConfigDetails(router_name);

			if (routerObj == null) {

				routerObj = new Router();
				routerObj.setRouter_id(String.valueOf(seqDao.getRouterNextSequenceId(ROUTER)));
				routerObj.setRouter_name(router_name);
			}

			List<RouterConfigDetails> routerConfigDetailsList = routerObj.getRouterConfigDetailsObj();
			if (routerConfigDetailsList == null) {
				routerConfigDetailsList = new ArrayList<RouterConfigDetails>();
			}
			for (int i = 0; i < protocolList.size(); i++) {
				ProtocolModel protocolModel = protocolList.get(i);

				RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
				routerConfigDetails.setDate(new Date());
				routerConfigDetails.setProtocol(protocolModel.getProtocol_name());

				if ("ipsla".equals(protocolModel.getProtocol_name())) {
					routerConfigDetails.setCos_entry_number(protocolModel.getCos_entry_number());
					routerConfigDetails.setCustomer_name(protocolModel.getCustomer_name());
					routerConfigDetails.setDestination_address(protocolModel.getDestination_address());
					routerConfigDetails.setSource_address(protocolModel.getSource_address());
					routerConfigDetails.setRouter_config_details_id(
							String.valueOf(seqDao.getRouterConfigDetailsNextSequenceId(ROUTER_CONFIG_VERSION)));
					routerConfigDetailsList.add(routerConfigDetails);
				}
				if ("bgp".equals(protocolModel.getProtocol_name())) {
					HashMap<String, String> neighbor = protocolModel.getNeighbors();
					HashMap<String, String> neighbormap = new HashMap<String, String>();
					routerConfigDetails.setAs_number(protocolModel.getAs_number());
					routerConfigDetails.setRouter_id(protocolModel.getRouter_id());

					String as_number = neighbor.get("as_number").toString();
					String peer_ip = neighbor.get("peer_ip").toString();

					neighbormap.put("as_number", as_number);
					neighbormap.put("peer_ip", peer_ip);

					routerConfigDetails.setNeighbors(neighbormap);
					routerConfigDetailsList.add(routerConfigDetails);
				}
				if ("ospf".equals(protocolModel.getProtocol_name())) {
					HashMap<String, String> networks = protocolModel.getNetworks();
					HashMap<String, String> networksmap = new HashMap<String, String>();

					String subnet_ip = networks.get("subnet_ip").toString();
					String area_id = networks.get("area_id").toString();

					networksmap.put("subnet_ip", subnet_ip);
					networksmap.put("area_id", area_id);

					routerConfigDetails.setNetworks(networksmap);
					routerConfigDetails.setProcess_id(protocolModel.getProcess_id());
					routerConfigDetailsList.add(routerConfigDetails);
				}

			}
			routerObj.setRouterConfigDetailsObj(routerConfigDetailsList);
			System.out.println("INFO" + routerObj.toString());
			routerConfigDetailsRepo.save(routerObj);

			response.setStatus(Boolean.TRUE);
			response.setResponseDetail("Router Config Information added successfully.");
			System.out.println("Router Config Details record saved Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(Boolean.FALSE);
			response.setResponseDetail("Router Config Information addition failed.");
		}

		return response;

	}

	@Override
	public JsonResponse<RouterConfigModel> add(RouterConfigModel request) {
		JsonResponse<RouterConfigModel> response = new JsonResponse<RouterConfigModel>();
		response.setResponseBody(null);
		try {
			String version = String.valueOf(seqDao.getVersion(VERSION));
			Field declaredField = RouterConfigModel.class.getDeclaredField("router");
			String router_name = declaredField.getAnnotation(JsonProperty.class).value();
			System.out.println("RouterName"+router_name);
			
			/*Router router = request.getRouter();
			List<ProtocolModel> protocolList = router.getProtocol();
			String version = String.valueOf(seqDao.getVersion(VERSION));
			 */

			Bgp bgp = request.getRouter().getBgp();
			Ospf ospf = request.getRouter().getOspf();
			List<Ipsla> ipslaList = request.getRouter().getIpsla();
			
			String bgpsimpleName = Bgp.class.getSimpleName().replace("B", "b");
			String ospfsimpleName = Ospf.class.getSimpleName().replace("O", "o");
			String ipslasimpleName = Ipsla.class.getSimpleName().replace("I", "i");
			
			
			 //String string = ospf.getClass().toString();
			Router routerObj = this.getRouterConfigDetails(router_name);
			if (routerObj == null) {

				routerObj = new Router();
				routerObj.setRouter_id(String.valueOf(seqDao.getRouterNextSequenceId(ROUTER)));
				routerObj.setRouter_name(router_name);
			}

			List<RouterConfigDetails> routerConfigDetailsList = routerObj.getRouterConfigDetailsObj();
			if (routerConfigDetailsList == null) {
				routerConfigDetailsList = new ArrayList<RouterConfigDetails>();
				
			}
			if ("bgp".equals(bgpsimpleName)) {
				RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
				routerConfigDetails.setVersion_id(version);
				routerConfigDetails.setDate(new Date());
				routerConfigDetails.setProtocol(bgpsimpleName);
				routerConfigDetails.setAs_number(bgp.getAsNumber());
				routerConfigDetails.setRouter_id(bgp.getRouterId());
				
				Neighbors neighbors = bgp.getNeighbors();
				String neigbor_asNumber = neighbors.getAsNumber();
				String peerIp = neighbors.getPeerIp();
				
				HashMap<String, String> neighbormap = new HashMap<String, String>();

				neighbormap.put("as_number", neigbor_asNumber);
				neighbormap.put("peer_ip", peerIp);

				routerConfigDetails.setNeighbors(neighbormap);
				routerConfigDetailsList.add(routerConfigDetails);
			}
			
				if ("ospf".equals(ospfsimpleName)) {
					RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
					routerConfigDetails.setVersion_id(version);
					routerConfigDetails.setDate(new Date());
					routerConfigDetails.setProtocol(ospfsimpleName);
					routerConfigDetails.setProcess_id(ospf.getProcessId());
					
					Networks networks = ospf.getNetworks();
					
					String subnetIp = networks.getSubnetIp();
					String areaId = networks.getAreaId();
					
					HashMap<String, String> networksmap = new HashMap<String, String>();

					networksmap.put("subnet_ip", subnetIp);
					networksmap.put("area_id", areaId);

					routerConfigDetails.setNetworks(networksmap);
					routerConfigDetailsList.add(routerConfigDetails);
				}
				for (Ipsla ipslaObj : ipslaList) {
					if ("ipsla".equals(ipslasimpleName)) 
					{
						RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
						routerConfigDetails.setVersion_id(version);
						routerConfigDetails.setDate(new Date());
						routerConfigDetails.setProtocol(ipslasimpleName);
						routerConfigDetails.setCos_entry_number(ipslaObj.getCosEntryNumber());
						routerConfigDetails.setCustomer_name(ipslaObj.getCustomerName());
						routerConfigDetails.setDestination_address(ipslaObj.getDestinationAddress());
						routerConfigDetails.setSource_address(ipslaObj.getSourceAddress());
						routerConfigDetails.setRouter_config_details_id(
								String.valueOf(seqDao.getRouterConfigDetailsNextSequenceId(ROUTER_CONFIG_VERSION)));
						routerConfigDetailsList.add(routerConfigDetails);
					}
				}
				
				
			
		
			
			
			/*for (int i = 0; i < protocolList.size(); i++) {
				ProtocolModel protocolModel = protocolList.get(i);

				RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
				routerConfigDetails.setDate(new Date());
				routerConfigDetails.setProtocol(protocolModel.getProtocol_name());

				if ("ipsla".equals(protocolModel.getProtocol_name())) {
					routerConfigDetails.setCos_entry_number(protocolModel.getCos_entry_number());
					routerConfigDetails.setCustomer_name(protocolModel.getCustomer_name());
					routerConfigDetails.setDestination_address(protocolModel.getDestination_address());
					routerConfigDetails.setSource_address(protocolModel.getSource_address());
					routerConfigDetails.setRouter_config_details_id(
							String.valueOf(seqDao.getRouterConfigDetailsNextSequenceId(ROUTER_CONFIG_VERSION)));
					routerConfigDetailsList.add(routerConfigDetails);
				}
				if ("bgp".equals(protocolModel.getProtocol_name())) {
					HashMap<String, String> neighbor = protocolModel.getNeighbors();
					HashMap<String, String> neighbormap = new HashMap<String, String>();
					routerConfigDetails.setAs_number(protocolModel.getAs_number());
					routerConfigDetails.setRouter_id(protocolModel.getRouter_id());

					String as_number = neighbor.get("as_number").toString();
					String peer_ip = neighbor.get("peer_ip").toString();

					neighbormap.put("as_number", as_number);
					neighbormap.put("peer_ip", peer_ip);

					routerConfigDetails.setNeighbors(neighbormap);
					routerConfigDetailsList.add(routerConfigDetails);
				}
				if ("ospf".equals(protocolModel.getProtocol_name())) {
					HashMap<String, String> networks = protocolModel.getNetworks();
					HashMap<String, String> networksmap = new HashMap<String, String>();

					String subnet_ip = networks.get("subnet_ip").toString();
					String area_id = networks.get("area_id").toString();

					networksmap.put("subnet_ip", subnet_ip);
					networksmap.put("area_id", area_id);

					routerConfigDetails.setNetworks(networksmap);
					routerConfigDetails.setProcess_id(protocolModel.getProcess_id());
					routerConfigDetailsList.add(routerConfigDetails);
				}

			}*/
			routerObj.setRouterConfigDetailsObj(routerConfigDetailsList);
			System.out.println("INFO" + routerObj.toString());
			routerConfigDetailsRepo.save(routerObj);

			response.setStatus(Boolean.TRUE);
			response.setResponseDetail("Router Config Information added successfully.");
			System.out.println("Router Config Details record saved Successfully");
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(Boolean.FALSE);
			response.setResponseDetail("Router Config Information addition failed.");
		}
		return response;
	}

	@Override
	public List<String> getVersionHistory() {
		
		
		return null;
	}

	/*
	 * @Override public JsonResponse<RouterConfigDetailsRestModel>
	 * addRouterConfigDetailsnew(ConfigDetailsRestModel router) {
	 * 
	 * JsonResponse<RouterConfigDetailsRestModel> response = new
	 * JsonResponse<RouterConfigDetailsRestModel>();
	 * response.setResponseBody(null); try { String
	 * router_name=router.getRouter(); List<ProtocolModel> protocolList =
	 * router.getProtocol(); String version =
	 * String.valueOf(seqDao.getVersion(VERSION));
	 * 
	 * Router routerObj = this.getRouterConfigDetails(router_name);
	 * 
	 * 
	 * if(routerObj==null) {
	 * 
	 * routerObj=new Router();
	 * routerObj.setRouter_id(String.valueOf(seqDao.getRouterNextSequenceId(
	 * ROUTER))); routerObj.setRouter_name(router_name); }
	 * 
	 * List<RouterConfigDetails> routerConfigDetailsList =
	 * routerObj.getRouterConfigDetailsObj(); if(routerConfigDetailsList==null)
	 * { routerConfigDetailsList=new ArrayList<RouterConfigDetails>(); } for
	 * (int i=0;i<protocolList.size();i++) { ProtocolModel protocolModel =
	 * protocolList.get(i);
	 * 
	 * RouterConfigDetails routerConfigDetails = new RouterConfigDetails();
	 * routerConfigDetails.setDate(new Date());
	 * routerConfigDetails.setProtocol(protocolModel.getProtocol_name());
	 * 
	 * if("ipsla".equals(protocolModel.getProtocol_name())) {
	 * routerConfigDetails.setCos_entry_number(protocolModel.getCos_entry_number
	 * ());
	 * routerConfigDetails.setCustomer_name(protocolModel.getCustomer_name());
	 * routerConfigDetails.setDestination_address(protocolModel.
	 * getDestination_address());
	 * routerConfigDetails.setSource_address(protocolModel.getSource_address());
	 * routerConfigDetails.setRouter_config_details_id(String.valueOf(seqDao.
	 * getRouterConfigDetailsNextSequenceId(ROUTER_CONFIG_VERSION)));
	 * routerConfigDetailsList.add(routerConfigDetails); }
	 * if("bgp".equals(protocolModel.getProtocol_name())) { HashMap<String,
	 * String> neighbor = protocolModel.getNeighbors(); HashMap<String, String>
	 * neighbormap = new HashMap<String, String>();
	 * routerConfigDetails.setAs_number(protocolModel.getAs_number());
	 * routerConfigDetails.setRouter_id(protocolModel.getRouter_id());
	 * 
	 * String as_number = neighbor.get("as_number").toString(); String peer_ip =
	 * neighbor.get("peer_ip").toString();
	 * 
	 * neighbormap.put("as_number", as_number); neighbormap.put("peer_ip",
	 * peer_ip);
	 * 
	 * routerConfigDetails.setNeighbors(neighbormap);
	 * routerConfigDetailsList.add(routerConfigDetails); }
	 * if("ospf".equals(protocolModel.getProtocol_name())) { HashMap<String,
	 * String> networks = protocolModel.getNetworks(); HashMap<String, String>
	 * networksmap = new HashMap<String, String>();
	 * 
	 * String subnet_ip = networks.get("subnet_ip").toString(); String area_id =
	 * networks.get("area_id").toString();
	 * 
	 * networksmap.put("subnet_ip", subnet_ip); networksmap.put("area_id",
	 * area_id);
	 * 
	 * routerConfigDetails.setNetworks(networksmap);
	 * routerConfigDetails.setProcess_id(protocolModel.getProcess_id());
	 * routerConfigDetailsList.add(routerConfigDetails); }
	 * 
	 * } routerObj.setRouterConfigDetailsObj(routerConfigDetailsList);
	 * System.out.println("INFO"+routerObj.toString());
	 * routerConfigDetailsRepo.save(routerObj);
	 * 
	 * response.setStatus(Boolean.TRUE); response.setResponseDetail(
	 * "Router Config Information added successfully."); System.out.println(
	 * "Router Config Details record saved Successfully"); } catch (Exception e)
	 * { e.printStackTrace(); response.setStatus(Boolean.FALSE);
	 * response.setResponseDetail("Router Config Information addition failed.");
	 * }
	 * 
	 * 
	 * 
	 * 
	 * return response;
	 * 
	 * 
	 * }
	 */

}
