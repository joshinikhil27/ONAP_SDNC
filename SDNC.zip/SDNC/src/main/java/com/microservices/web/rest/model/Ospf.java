
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "process-id",
    "networks"
})
public class Ospf {

	//private String ospf_name="ospf";
    @JsonProperty("process-id")
    private String processId;
    @JsonProperty("networks")
    private Networks networks;
    

    @JsonProperty("process-id")
    public String getProcessId() {
        return processId;
    }

    @JsonProperty("process-id")
    public void setProcessId(String processId) {
        this.processId = processId;
    }

    @JsonProperty("networks")
    public Networks getNetworks() {
        return networks;
    }

    @JsonProperty("networks")
    public void setNetworks(Networks networks) {
        this.networks = networks;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

	/*public String getOspf_name() {
		return ospf_name;
	}

	public void setOspf_name(String ospf_name) {
		this.ospf_name = ospf_name;
	}
*/
   

}
