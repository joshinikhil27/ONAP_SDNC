
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "cos-entry-number",
    "destination-address",
    "source-address",
    "customer-name"
})
public class Ipsla {

	//private String ipsla_name="ipsla";
    @JsonProperty("cos-entry-number")
    private String cosEntryNumber;
    @JsonProperty("destination-address")
    private String destinationAddress;
    @JsonProperty("source-address")
    private String sourceAddress;
    @JsonProperty("customer-name")
    private String customerName;
   

    @JsonProperty("cos-entry-number")
    public String getCosEntryNumber() {
        return cosEntryNumber;
    }

    @JsonProperty("cos-entry-number")
    public void setCosEntryNumber(String cosEntryNumber) {
        this.cosEntryNumber = cosEntryNumber;
    }

    @JsonProperty("destination-address")
    public String getDestinationAddress() {
        return destinationAddress;
    }

    @JsonProperty("destination-address")
    public void setDestinationAddress(String destinationAddress) {
        this.destinationAddress = destinationAddress;
    }

    @JsonProperty("source-address")
    public String getSourceAddress() {
        return sourceAddress;
    }

    @JsonProperty("source-address")
    public void setSourceAddress(String sourceAddress) {
        this.sourceAddress = sourceAddress;
    }

    @JsonProperty("customer-name")
    public String getCustomerName() {
        return customerName;
    }

    @JsonProperty("customer-name")
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

/*	public String getIpsla_name() {
		return ipsla_name;
	}

	public void setIpsla_name(String ipsla_name) {
		this.ipsla_name = ipsla_name;
	}

*/
}
