package com.microservices.web.rest.model;

public class PreTestModel {

	String ip;
	
	
	
	

	public String getIp() {
		return ip;
	}





	public void setIp(String ip) {
		this.ip = ip;
	}





	public PreTestModel() {
		super();
	}
		
	
}
