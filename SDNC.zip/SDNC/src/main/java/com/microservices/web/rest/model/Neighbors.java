
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "as-number",
    "peer-ip"
})
public class Neighbors {

    @JsonProperty("as-number")
    private String asNumber;
    @JsonProperty("peer-ip")
    private String peerIp;
    

    @JsonProperty("as-number")
    public String getAsNumber() {
        return asNumber;
    }

    @JsonProperty("as-number")
    public void setAsNumber(String asNumber) {
        this.asNumber = asNumber;
    }

    @JsonProperty("peer-ip")
    public String getPeerIp() {
        return peerIp;
    }

    @JsonProperty("peer-ip")
    public void setPeerIp(String peerIp) {
        this.peerIp = peerIp;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

   

}
