
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.annotation.JsonNaming;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "as-number", "router-id", "neighbors" })
public class Bgp {

	//private String bgp_name = "bgp";
	@JsonProperty("as-number")
	private String asNumber;
	@JsonProperty("router-id")
	private String routerId;
	@JsonProperty("neighbors")
	private Neighbors neighbors;

	@JsonProperty("as-number")
	public String getAsNumber() {
		return asNumber;
	}

	@JsonProperty("as-number")
	public void setAsNumber(String asNumber) {
		this.asNumber = asNumber;
	}

	@JsonProperty("router-id")
	public String getRouterId() {
		return routerId;
	}

	@JsonProperty("router-id")
	public void setRouterId(String routerId) {
		this.routerId = routerId;
	}

	@JsonProperty("neighbors")
	public Neighbors getNeighbors() {
		return neighbors;
	}

	@JsonProperty("neighbors")
	public void setNeighbors(Neighbors neighbors) {
		this.neighbors = neighbors;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this);
	}

/*	public String getBgp_name() {
		return bgp_name;
	}

	public void setBgp_name(String bgp_name) {
		this.bgp_name = bgp_name;
	}
*/
}
