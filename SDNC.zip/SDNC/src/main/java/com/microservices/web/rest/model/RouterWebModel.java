
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "ospf",
    "bgp",
    "ipsla"
})
public class RouterWebModel {

    @JsonProperty("ospf")
    private Ospf ospf;
    @JsonProperty("bgp")
    private Bgp bgp;
    @JsonProperty("ipsla")
    private List<Ipsla> ipsla = null;
   

    @JsonProperty("ospf")
    public Ospf getOspf() {
        return ospf;
    }

    @JsonProperty("ospf")
    public void setOspf(Ospf ospf) {
        this.ospf = ospf;
    }

    @JsonProperty("bgp")
    public Bgp getBgp() {
        return bgp;
    }

    @JsonProperty("bgp")
    public void setBgp(Bgp bgp) {
        this.bgp = bgp;
    }

    @JsonProperty("ipsla")
    public List<Ipsla> getIpsla() {
        return ipsla;
    }

    @JsonProperty("ipsla")
    public void setIpsla(List<Ipsla> ipsla) {
        this.ipsla = ipsla;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    

}
