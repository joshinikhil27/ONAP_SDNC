
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "router"
})
public class RouterConfigModel {
	
	//private String router_name="router";

    @JsonProperty("router")
    private RouterWebModel router;
    
    @JsonProperty("router")
    public RouterWebModel getRouter() {
        return router;
    }

    @JsonProperty("router")
    public void setRouter(RouterWebModel router) {
        this.router = router;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

	/*public String getRouter_name() {
		return router_name;
	}

	public void setRouter_name(String router_name) {
		this.router_name = router_name;
	}*/

   

}
