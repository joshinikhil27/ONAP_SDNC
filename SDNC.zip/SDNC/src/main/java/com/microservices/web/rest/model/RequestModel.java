package com.microservices.web.rest.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class RequestModel {

	@JsonProperty(value = JSONTags.TAG_ROUTER)
	String router;
	
	@JsonProperty(value = JSONTags.TAG_OSPF)
	String ospf;
	
	@JsonProperty(value = JSONTags.TAG_PROCESS_ID)
	String process_id;
	
	
	public String getRouter() {
		return router;
	}


	public void setRouter(String router) {
		this.router = router;
	}


	public String getOspf() {
		return ospf;
	}


	public void setOspf(String ospf) {
		this.ospf = ospf;
	}


	public String getProcess_id() {
		return process_id;
	}


	public void setProcess_id(String process_id) {
		this.process_id = process_id;
	}


	public RequestModel() {
		super();
	}


	
	
	

	

	

	

}
