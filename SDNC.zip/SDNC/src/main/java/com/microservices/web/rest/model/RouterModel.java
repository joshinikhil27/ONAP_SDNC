package com.microservices.web.rest.model;

public class RouterModel {

	String router_name;
	
	
	
	public String getRouter_name() {
		return router_name;
	}



	public void setRouter_name(String router_name) {
		this.router_name = router_name;
	}



	public RouterModel() {
		super();
	}
		
	
}
