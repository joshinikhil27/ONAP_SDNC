package com.microservices.web.rest.model;

public class ShellScriptLocationRestModel {

	String file_location;
	
	
	public ShellScriptLocationRestModel() {
		super();
	}


	public String getFile_location() {
		return file_location;
	}


	public void setFile_location(String file_location) {
		this.file_location = file_location;
	}
	
	
}
