package com.microservices.web.rest.model;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ConfigDetailsRestModel {

	@JsonProperty(value = JSONTags.TAG_ROUTER)
	String router;
	
	@JsonProperty(value = JSONTags.TAG_DATE)
	String date;

	List<ProtocolModel> protocol;


	public ConfigDetailsRestModel() {
		super();
	}


	public String getRouter() {
		return router;
	}


	public void setRouter(String router) {
		this.router = router;
	}


	public String getDate() {
		return date;
	}


	public void setDate(String date) {
		this.date = date;
	}


	public List<ProtocolModel> getProtocol() {
		return protocol;
	}


	public void setProtocol(List<ProtocolModel> protocol) {
		this.protocol = protocol;
	}

	
	

	

	

	

}
