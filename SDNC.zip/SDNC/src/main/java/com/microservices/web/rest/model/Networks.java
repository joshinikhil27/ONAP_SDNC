
package com.microservices.web.rest.model;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "subnet-ip",
    "area-id"
})
public class Networks {

    @JsonProperty("subnet-ip")
    private String subnetIp;
    @JsonProperty("area-id")
    private String areaId;
    

    @JsonProperty("subnet-ip")
    public String getSubnetIp() {
        return subnetIp;
    }

    @JsonProperty("subnet-ip")
    public void setSubnetIp(String subnetIp) {
        this.subnetIp = subnetIp;
    }

    @JsonProperty("area-id")
    public String getAreaId() {
        return areaId;
    }

    @JsonProperty("area-id")
    public void setAreaId(String areaId) {
        this.areaId = areaId;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    

}
