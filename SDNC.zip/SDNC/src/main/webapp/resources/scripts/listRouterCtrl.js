var app = angular.module('App', []);
app.controller('listRouterCtrl', [ '$scope', '$http', function($scope, $http) {
	console.log("HAHAHAHA")
	
	$scope.get=function()
	{
	debugger
	$http({
		method : 'GET',
		url : '/listRouters',
		contentType : "application/json",
	}).then(function(success) {
		console.log("ROUTERLIST");

	}, function(err) {
		console.log("error");
	});
}
}

]);
