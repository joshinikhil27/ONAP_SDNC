var app = angular.module('App',[]);
app.controller('HomeController',function($scope, $http){
		
	$scope.runPreTest=function()
	{
		 //$(".pageoverlay").show();
		$scope.showLoader = true;
	$http({
		method : 'GET',
		url : '/runPreTest',
		contentType : "application/json",
	}).then(function(success) {
		// $(".pageoverlay").hide();
		 $scope.showLoader = false;
		$scope.pretestresponse = 'Pre-test has been '+ success.data.response_body;
		
	}, function(err) {
		 $scope.showLoader = false;
	});
}
	
	
		$scope.getAllRouters=function()
		{
		$http({
			method : 'GET',
			url : '/listRouters',
			contentType : "application/json",
		}).then(function(success) {
			$scope.data = success.data.response_body;
			
		}, function(err) {
		});
	}
		$scope.getVersions=function(name){
			
			$http({
				method : 'GET',
				url : '/routerDetails/'+name,
				contentType : "application/json",
			})
		       .then(function(res){
		    	   $(".pageoverlay").hide();
		          $scope.sample1 = res.data.response_body;
		          $scope.dispalyKeys = $scope.sample1;
		          //$scope.router1 = tryJson($scope.sample1);
		          
		         angular.forEach($scope.sample1,function(value,key){
		        	  $scope[key] = [];
		        	  $scope[key] = tryJson(value);
		          });
		    });
		};
		function isJson(item) {
	        item = typeof item !== "string"
	            ? JSON.stringify(item)
	            : item;

	        try {
	            item = JSON.parse(item);
	        } catch (e) {
	            return false;
	        }

	        if (typeof item === "object" && item !== null) {
	            return true;
	        }
	        return false;
	    }
		
		
		
		function tryJson(data){
			var keyArray1=[];
			var valArray1 = [];
			angular.forEach(data,function(value1,key1){
				if(isNaN(key1)){
					var obj = {};
					if(!isJson(value1)){
						obj[key1] = value1;
						keyArray1.push(obj);
					}else{
						obj[key1] = 'Parent';
						keyArray1.push(obj);
						angular.forEach(value1,function(value2,key2){
							if(isNaN(key2)){
								var obj = {};
								if(!isJson(value2)){
									obj[key2] = value2;
									keyArray1.push(obj);
								}else{
									obj[key2] = 'Child1';
									keyArray1.push(obj);
									angular.forEach(value2,function(value3,key3){
										if(isNaN(key3)){
											var obj = {};
											if(!isJson(value3)){
												obj[key3] = value3;
												keyArray1.push(obj);
											}else{
												obj[key3] = 'Child2';
												keyArray1.push(obj);
												angular.forEach(value3,function(value6,key6){
													if(isNaN(key6)){
														var obj = {};
														if(!isJson(value6)){
															obj[key6] = value6;
															keyArray1.push(obj);
														}else{
															obj[key6] = 'Child3';
															keyArray1.push(obj);
															/*angular.forEach(value3,function(value6,key6){
															
															});*/
														}
													}else{
														//Zero index
														angular.forEach(value6,function(value7,key7){
															if(isNaN(key7)){
																var obj = {};
																if(!isJson(value7)){
																	obj[key7] = value7;
																	keyArray1.push(obj);
																}else{
																	obj[key7] = 'Child3';
																	keyArray1.push(obj);
//																	angular.forEach(value5,function(value6,key6){
//																		
//																	});
																}
															}
														});
													}
												});
											}
										}else{
											//Zero index
											angular.forEach(value3,function(value5,key5){
												if(isNaN(key5)){
													var obj = {};
													if(!isJson(value5)){
														obj[key5] = value5;
														keyArray1.push(obj);
													}else{
														obj[key5] = 'Child1';
														keyArray1.push(obj);
//														angular.forEach(value5,function(value6,key6){
//															
//														});
													}
												}
											});
										}
									});
								}
							}else{
								//Zero index
								angular.forEach(value2,function(value4,key4){
									if(isNaN(key4)){
										var obj = {};
										if(!isJson(value4)){
											obj[key4] = value4;
											keyArray1.push(obj);
										}else{
											obj[key4] = 'Child1';
											keyArray1.push(obj);
//											angular.forEach(value4,function(value7,key7){
//												
//											});
										}
									}
								});
							}
						});
					}
				}else{
					//Zero index
					angular.forEach(value1,function(value8,key8){
						if(isNaN(key8)){
							var obj = {};
							if(!isJson(value8)){
								obj[key8] = value8;
								keyArray1.push(obj);
							}else{
								obj[key8] = 'Child1';
								keyArray1.push(obj);
								angular.forEach(value8,function(value9,key9){
									if(isNaN(key9)){
										var obj = {};
										if(!isJson(value9)){
											obj[key9] = value9;
											keyArray1.push(obj);
										}else{
											obj[key9] = 'Child2';
											keyArray1.push(obj);
											/*angular.forEach(value9,function(value10,key10){
												
											});*/
										}
									}else{
										angular.forEach(value9,function(value10,key10){
											if(isNaN(key10)){
												var obj = {};
												if(!isJson(value10)){
													obj[key10] = value10;
													keyArray1.push(obj);
												}else{
													obj[key10] = 'Child1';
													keyArray1.push(obj);
													/*angular.forEach(value8,function(value9,key9){
														
													});*/
												}
											}
										});
									}
								});
							}
						}
					});
				
				
				}
			});
			$scope.dispalyKeys = angular.copy(keyArray1);
			return keyArray1;
		}

		$scope.test = function(json) {
			
			document.getElementById('files')
			
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/process-definition/key/Device-Verification/submit-form',
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
				$scope.process_id=success.data.id;
				$("#updateDeviceSuccess").modal('show');
			}, function(err) {
				
			});
		}
		$scope.getCurrentTask =function()
		{
			$http({
				method : 'GET',
				url : 'http://localhost:8080/engine-rest/task/?processInstanceId='+$scope.process_id,
				contentType : "application/json"
			}).then(function(success) {
				$scope.task_id=(success.data[0].id)
				$scope.PT();
				//var url='http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete'
			}, function(err) {
			});
			
		}
		
		$scope.getNextTask =function()
		{
			var json ={
					"variables": {
						"approver": {
							"value": "Demo",
							"type": "String"
						}
					}
				}
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/task/?processInstanceId='+$scope.task_id,
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
				var id;
				angular.forEach(success.data,function(value,key){
					angular.forEach(value,function(value1,key1){
						if(value1 ==  "UpdateDataBase"){
							id = key;
							$("#preTestSuccess").modal('show');
							
						}
						
						if(value1 ==  "RetriveConfiguration"){
							id = key;
							$("#preTestFailure").modal('show');
						}
						
						if(value1 ==  "Update Device Configuration"){
							id = key;
							$("#updateDevice").modal('show');
						}
						
					})
				});
				$scope.task_id=(success.data[id].id)
				console.log(success.data[id].name);
				//$scope.finalstep();
				//var url='http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete'
			}, function(err) {
			});
			
		}
		
		$scope.getNextTask1 =function()
		{
			var json ={
					"variables": {
						"approver": {
							"value": "Demo",
							"type": "String"
						}
					}
				}
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/task/?processInstanceId='+$scope.task_id,
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
				var id;
				angular.forEach(success.data,function(value,key){
					angular.forEach(value,function(value1,key1){
						if(value1 ==  "Update Device Configuration"){
							id = key;
						}
					})
				});
				$scope.task_id=(success.data[id].id)
				console.log(success.data[id].name);
				$scope.finalstep();
				//var url='http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete'
			}, function(err) {
			});
			
		}
		
		
		
		$scope.PT=function()
		{
		
		var json ={
			"variables": {
				"approver": {
					"value": "Demo",
					"type": "String"
				}
			}
		}
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete',
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
					$("#preTestFinished").modal('show');
			}, function(err) {
				
			});
		}

		
		$scope.finalstep=function()
		{
		
		var json ={
			"variables": {
				"approver": {
					"value": "Demo",
					"type": "String"
				}
			}
		}
			console.log("in finalstep");
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete',
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
					$("#processSuccess").modal('show');
			}, function(err) {
				console.log(err);
				
			});
		}
		
		
		$scope.finalstep1=function()
		{
		
		var json ={
			"variables": {
				"approver": {
					"value": "Demo",
					"type": "String"
				}
			}
		}
			console.log("in finalstep1");
			$http({
				method : 'POST',
				url : 'http://localhost:8080/engine-rest/task/'+$scope.task_id+'/complete',
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
					$("#updateDevice").modal('show');
			}, function(err) {
				console.log(err);
				
			});
		}
		

		var json;

		function handleFileSelect(evt) {
			var files = evt.target.files; // FileList object

			// files is a FileList of File objects. List some properties.

		}

		document.getElementById('files').addEventListener('change',
				handleFileSelect, false);

		function handleFileSelect(evt) {
			var files = evt.target.files; // FileList object

			// files is a FileList of File objects. List some properties.
			var output = [];
			for (var i = 0, f; f = files[i]; i++) {
				var reader = new FileReader();

				// Closure to capture the file information.
				reader.onload = (function(theFile) {
					return function(e) {
						// console.log('e readAsText = ', e);
						// console.log('e readAsText target = ', e.target);
						try {
							$scope.json = JSON.parse(e.target.result);

							// alert('json global var has been set to parsed
							// json of this file here it is unevaled = \n' +
							// JSON.stringify(json));
						} catch (ex) {
							alert('ex when trying to parse json = ' + ex);
						}
					}
				})(f);
				reader.readAsText(f);
			}

		}

		document.getElementById('files').addEventListener('change',
				handleFileSelect, false);
		
		$scope.onNext = function(json) {
			
			$scope.getCurrentTask();
			/* var origin = window.location.origin;
			 console.log("ORIGIN"+origin);
   	        window.location.href = origin+'/home';*/
		}
		
$scope.onClose = function(json) {
			
			var origin = window.location.origin;
			 console.log("ORIGIN"+origin);
   	        window.location.href = origin+'/home';
		}
		

/*		$scope.updateDeviceConfiguration = function(json) {
			debugger;
			console.log("INSIDE UPDATE DEVICE CONFIG")
			document.getElementById('files')
			console.log("JSON" + angular.toJson(json))
			debugger
			$http({
				method : 'POST',
				url : '/updateDeviceConfiguration',
				contentType : "application/json",
				data : angular.toJson(json)
			}).then(function(success) {
				console.log("Entered");
				$("#updateDeviceModal").modal('show');
				$scope.updateDeviceResponse = 'Device Configuration updation is '+ success.data.error_code;
				console.log("Update Device Response"+JSON.stringify(success.data.error_code));
				
			}, function(err) {
				console.log("error");
			});
		}

	*/	
});