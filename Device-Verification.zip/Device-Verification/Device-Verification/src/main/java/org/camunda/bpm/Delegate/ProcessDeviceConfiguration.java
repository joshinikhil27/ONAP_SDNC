package org.camunda.bpm.Delegate;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.model.bpmn.BpmnModelInstance;
import org.json.JSONObject;




public class ProcessDeviceConfiguration  implements JavaDelegate  {


	    private String status;
	private static final Logger logger = Logger.getLogger(ProcessDeviceConfiguration.class.getName());
	
	public void execute(DelegateExecution execution) throws Exception {
		try
		{
		logger.info("In PROCESS DEVICE CLASS");
		
		// Process Response.
		
		String deviceConfigurationResponse=(String) execution.getVariable("deviceConfigurationResponse");
		logger.info("DEVICE CONFIG JSON"+deviceConfigurationResponse);
		deviceConfigurationResponse = deviceConfigurationResponse.replaceAll("\n", "\\n");
		JSONObject deviceConfigResOject = new JSONObject(deviceConfigurationResponse);
		
		status = deviceConfigResOject.getString("error_code");
		logger.info("STATUS"+status);
		execution.setVariable("deviceConfigurationStatus", status);
		
		if(status.equals("SUCCESS")){
			JSONObject devicePreTestRequestObject = new JSONObject();
			devicePreTestRequestObject.put("IP", "127.0.0.1");
			execution.setVariable("performPreTestJSON", devicePreTestRequestObject.toString());
			logger.info("IN PRETEST");
			execution.setVariable("devicePreTestURL", "http://104.130.165.61:8282/runPreTest");
			logger.info("AFTER PRETEST"+execution);
			
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}

}
